from django.shortcuts import render
from mainapp.models import Product, ProductCategory


# Create your views here.
def index(request):
    context = {'page_title': 'Главная', }
    return render(request, 'mainapp/index.html', context)


def contact(request):
    contacts = [
        {'city': 'Москва',
         'phone': '+7-888-888-8888',
         'email': 'smth@google.com',
         'address': 'В пределах МКАД'},
        {'city': 'Москва 1',
         'phone': '+7-888-888-8888',
         'email': 'smth@google.com',
         'address': 'В пределах МКАД'},
        {'city': 'Москва 2',
         'phone': '+7-888-888-8888',
         'email': 'smth@google.com',
         'address': 'В пределах МКАД'},
    ]
    context = {'page_title': 'Контакты',
               'contacts': contacts,
               }
    return render(request, 'mainapp/contact.html', context)


def products(request):
    product_1 = Product.objects.all()[0]

    pcategory = ProductCategory.objects.all()

    context = {
        'page_title': 'Каталог',
        'product_1': product_1,
        'pcategory': pcategory}
    return render(request, 'mainapp/products.html', context)


def category(request, pk):
    print (pk)
