def products(request):
    context = {'page_title': 'Каталог',} - это кортеж?
почему словарь передаем кортежем?

c antistatic картинки отображаются, c static нет